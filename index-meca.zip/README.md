# Download do plantuml        

```
wget https://github.com/plantuml/plantuml/releases/download/v1.2026.1/plantuml-mit-1.2026.1.jar
```

# Geração dos diagramas

```
java -jar plantuml-mit-1.2026.1.jar *.txt
```